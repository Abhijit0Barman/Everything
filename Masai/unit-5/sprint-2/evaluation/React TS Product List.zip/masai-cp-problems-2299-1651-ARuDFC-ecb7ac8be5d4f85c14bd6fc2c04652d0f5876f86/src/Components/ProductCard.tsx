import React from "react";

export const ProductCard = () => {
  return (
    <div className={`product-card`}>
      {/* Add all elements of product card here */}
    </div>
  );
};
