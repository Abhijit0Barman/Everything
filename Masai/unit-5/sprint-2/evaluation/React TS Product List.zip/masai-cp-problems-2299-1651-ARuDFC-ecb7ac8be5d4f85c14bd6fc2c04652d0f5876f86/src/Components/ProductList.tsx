import React from "react";

const ProductList = () => {
  // const [products, setProducts] = useState([]);

  return (
    <div className={`product-list`}>
      {/* Add all product cards here in grid format  */}
    </div>
  );
};

export default ProductList;
