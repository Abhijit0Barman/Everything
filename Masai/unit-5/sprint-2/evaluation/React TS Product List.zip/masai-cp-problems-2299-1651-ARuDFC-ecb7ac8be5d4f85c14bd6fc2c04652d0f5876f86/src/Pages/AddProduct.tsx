import React from "react";
import { Navbar } from "../Components/Navbar";

export const AddProduct = () => {
  return (
    <div>
      <Navbar />
      <form>{/* Add all fields here to take product input */}</form>
    </div>
  );
};
