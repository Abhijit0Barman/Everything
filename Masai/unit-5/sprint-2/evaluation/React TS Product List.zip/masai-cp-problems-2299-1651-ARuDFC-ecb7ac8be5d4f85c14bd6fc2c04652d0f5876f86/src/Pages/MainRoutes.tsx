import React from "react";

export const MainRoutes = () => {
  return <div>MainRoutes</div>;
};
