import axios, { AxiosResponse } from "axios";

export const addProduct = () => {
  // Add product functionality here
};

export const getProducts = () => {
  // Get products functionality
};

export const updateLike = () => {
  // Update like functionality
};

export const updateDisLike = () => {
  // Update dislike functionality
};

export const deleteProduct = () => {
  // Delete functionality
};
