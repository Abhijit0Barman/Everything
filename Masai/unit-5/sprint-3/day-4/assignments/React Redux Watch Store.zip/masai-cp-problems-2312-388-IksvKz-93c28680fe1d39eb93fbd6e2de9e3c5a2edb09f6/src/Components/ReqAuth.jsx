//Create the HOC for protected Routes
const ReqAuth = () => {};

export default ReqAuth;
