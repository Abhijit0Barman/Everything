export const PrivateRoute = () => {
  return <>{/* Complete this higher order component  */}</>;
};
