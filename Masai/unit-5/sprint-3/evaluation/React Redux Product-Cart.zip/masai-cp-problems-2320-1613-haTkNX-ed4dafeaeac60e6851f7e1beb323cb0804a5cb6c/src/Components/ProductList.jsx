export const ProductList = () => {
  return (
    <div data-testid="product-list">
      {/* Map through products with ProductCard component  */}
    </div>
  );
};
