export const CartPage = () => {
  return <div data-testid="cart-list">{/* Map through cart store  */}</div>;
};
