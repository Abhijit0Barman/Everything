export const PrivateRoute = () => {
  return <div>PrivateRoute</div>;
};
