export const StudentCard = () => {
  return (
    <div className={"student-card"}>
      {/* Show student details here with a button to view details */}
    </div>
  );
};
