export const StudentList = () => {
  return (
    <div>
      <div data-testid="student-list">
        {/* Map through the student list using StudentCard component  */}
      </div>
    </div>
  );
};
