import { Route, Routes } from "react-router-dom";

export const MainRoutes = () => {
  return <Routes>{/* Add all routes here */}</Routes>;
};
