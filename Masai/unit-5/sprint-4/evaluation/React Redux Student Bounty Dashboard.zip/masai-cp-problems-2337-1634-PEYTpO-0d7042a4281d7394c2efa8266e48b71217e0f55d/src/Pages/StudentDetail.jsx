export const StudentDetail = () => {
  return (
    <div className={"student-card"}>
      <h1 className="student-id">{/* Show Student Id here */}</h1>
    </div>
  );
};
