const fs = require("fs");

// complete the following fubctions

function isNumber() {

}

function isStr() {

}

function isArray() {

}

function isObj() {

}

function cls() {

}

// Export All the functions

